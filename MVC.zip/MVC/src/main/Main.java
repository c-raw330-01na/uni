package main;

import controlador.VueloController;
import vista.VueloView;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VueloController vuelo =new VueloController(new VueloView());
	}

}
