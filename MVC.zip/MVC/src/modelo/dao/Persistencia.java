package modelo.dao;

public class Persistencia<T> {
	
}