/**
 * 
 */
/**
 * 
 */
module vista {
	requires java.desktop;
}